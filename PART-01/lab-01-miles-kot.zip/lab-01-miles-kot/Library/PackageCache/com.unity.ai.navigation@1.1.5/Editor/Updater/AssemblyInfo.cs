#if UNITY_2022_2_OR_NEWER
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.AI.Navigation.Editor.Tests")]
#endif
